--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP TABLE public.winners;
DROP TABLE public.userpicks;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: userpicks; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE userpicks (
    best_picture_toppick character varying(200),
    best_picture_midpick character varying(200),
    best_picture_botpick character varying(200),
    best_actor_in_a_leading_role_toppick character varying(200),
    best_actor_in_a_leading_role_midpick character varying(200),
    best_actor_in_a_leading_role_botpick character varying(200),
    best_actress_in_a_leading_role_toppick character varying(200),
    best_actress_in_a_leading_role_midpick character varying(200),
    best_actress_in_a_leading_role_botpick character varying(200),
    best_actor_in_a_supporting_role_toppick character varying(200),
    best_actor_in_a_supporting_role_midpick character varying(200),
    best_actor_in_a_supporting_role_botpick character varying(200),
    best_actress_in_a_supporting_role_toppick character varying(200),
    best_actress_in_a_supporting_role_midpick character varying(200),
    best_actress_in_a_supporting_role_botpick character varying(200),
    best_director_toppick character varying(200),
    best_director_midpick character varying(200),
    best_director_botpick character varying(200),
    best_animated_feature_toppick character varying(200),
    best_animated_feature_midpick character varying(200),
    best_animated_feature_botpick character varying(200),
    best_cinematography_toppick character varying(200),
    best_cinematography_midpick character varying(200),
    best_cinematography_botpick character varying(200),
    best_costume_design_toppick character varying(200),
    best_costume_design_midpick character varying(200),
    best_costume_design_botpick character varying(200),
    best_documentary_feature_toppick character varying(200),
    best_documentary_feature_midpick character varying(200),
    best_documentary_feature_botpick character varying(200),
    best_documentary_short_toppick character varying(200),
    best_documentary_short_midpick character varying(200),
    best_documentary_short_botpick character varying(200),
    best_film_editing_toppick character varying(200),
    best_film_editing_midpick character varying(200),
    best_film_editing_botpick character varying(200),
    best_foreign_language_film_toppick character varying(200),
    best_foreign_language_film_midpick character varying(200),
    best_foreign_language_film_botpick character varying(200),
    best_makeup_and_hairstyling_toppick character varying(200),
    best_makeup_and_hairstyling_midpick character varying(200),
    best_makeup_and_hairstyling_botpick character varying(200),
    best_original_score_toppick character varying(200),
    best_original_score_midpick character varying(200),
    best_original_score_botpick character varying(200),
    best_original_song_toppick character varying(200),
    best_original_song_midpick character varying(200),
    best_original_song_botpick character varying(200),
    best_production_design_toppick character varying(200),
    best_production_design_midpick character varying(200),
    best_production_design_botpick character varying(200),
    best_animated_short_film_toppick character varying(200),
    best_animated_short_film_midpick character varying(200),
    best_animated_short_film_botpick character varying(200),
    best_live_action_short_film_toppick character varying(200),
    best_live_action_short_film_midpick character varying(200),
    best_live_action_short_film_botpick character varying(200),
    best_sound_editing_toppick character varying(200),
    best_sound_editing_midpick character varying(200),
    best_sound_editing_botpick character varying(200),
    best_sound_mixing_toppick character varying(200),
    best_sound_mixing_midpick character varying(200),
    best_sound_mixing_botpick character varying(200),
    best_visual_effects_toppick character varying(200),
    best_visual_effects_midpick character varying(200),
    best_visual_effects_botpick character varying(200),
    best_adapted_screenplay_toppick character varying(200),
    best_adapted_screenplay_midpick character varying(200),
    best_adapted_screenplay_botpick character varying(200),
    best_original_screenplay_toppick character varying(200),
    best_original_screenplay_midpick character varying(200),
    best_original_screenplay_botpick character varying(200),
    username character varying(200),
    paid character varying(20)
);


ALTER TABLE public.userpicks OWNER TO postgres;

--
-- Name: winners; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE winners (
    category character varying(200),
    winner character varying(200)
);


ALTER TABLE public.winners OWNER TO postgres;

--
-- Data for Name: userpicks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY userpicks (best_picture_toppick, best_picture_midpick, best_picture_botpick, best_actor_in_a_leading_role_toppick, best_actor_in_a_leading_role_midpick, best_actor_in_a_leading_role_botpick, best_actress_in_a_leading_role_toppick, best_actress_in_a_leading_role_midpick, best_actress_in_a_leading_role_botpick, best_actor_in_a_supporting_role_toppick, best_actor_in_a_supporting_role_midpick, best_actor_in_a_supporting_role_botpick, best_actress_in_a_supporting_role_toppick, best_actress_in_a_supporting_role_midpick, best_actress_in_a_supporting_role_botpick, best_director_toppick, best_director_midpick, best_director_botpick, best_animated_feature_toppick, best_animated_feature_midpick, best_animated_feature_botpick, best_cinematography_toppick, best_cinematography_midpick, best_cinematography_botpick, best_costume_design_toppick, best_costume_design_midpick, best_costume_design_botpick, best_documentary_feature_toppick, best_documentary_feature_midpick, best_documentary_feature_botpick, best_documentary_short_toppick, best_documentary_short_midpick, best_documentary_short_botpick, best_film_editing_toppick, best_film_editing_midpick, best_film_editing_botpick, best_foreign_language_film_toppick, best_foreign_language_film_midpick, best_foreign_language_film_botpick, best_makeup_and_hairstyling_toppick, best_makeup_and_hairstyling_midpick, best_makeup_and_hairstyling_botpick, best_original_score_toppick, best_original_score_midpick, best_original_score_botpick, best_original_song_toppick, best_original_song_midpick, best_original_song_botpick, best_production_design_toppick, best_production_design_midpick, best_production_design_botpick, best_animated_short_film_toppick, best_animated_short_film_midpick, best_animated_short_film_botpick, best_live_action_short_film_toppick, best_live_action_short_film_midpick, best_live_action_short_film_botpick, best_sound_editing_toppick, best_sound_editing_midpick, best_sound_editing_botpick, best_sound_mixing_toppick, best_sound_mixing_midpick, best_sound_mixing_botpick, best_visual_effects_toppick, best_visual_effects_midpick, best_visual_effects_botpick, best_adapted_screenplay_toppick, best_adapted_screenplay_midpick, best_adapted_screenplay_botpick, best_original_screenplay_toppick, best_original_screenplay_midpick, best_original_screenplay_botpick, username, paid) FROM stdin;
\.
COPY userpicks (best_picture_toppick, best_picture_midpick, best_picture_botpick, best_actor_in_a_leading_role_toppick, best_actor_in_a_leading_role_midpick, best_actor_in_a_leading_role_botpick, best_actress_in_a_leading_role_toppick, best_actress_in_a_leading_role_midpick, best_actress_in_a_leading_role_botpick, best_actor_in_a_supporting_role_toppick, best_actor_in_a_supporting_role_midpick, best_actor_in_a_supporting_role_botpick, best_actress_in_a_supporting_role_toppick, best_actress_in_a_supporting_role_midpick, best_actress_in_a_supporting_role_botpick, best_director_toppick, best_director_midpick, best_director_botpick, best_animated_feature_toppick, best_animated_feature_midpick, best_animated_feature_botpick, best_cinematography_toppick, best_cinematography_midpick, best_cinematography_botpick, best_costume_design_toppick, best_costume_design_midpick, best_costume_design_botpick, best_documentary_feature_toppick, best_documentary_feature_midpick, best_documentary_feature_botpick, best_documentary_short_toppick, best_documentary_short_midpick, best_documentary_short_botpick, best_film_editing_toppick, best_film_editing_midpick, best_film_editing_botpick, best_foreign_language_film_toppick, best_foreign_language_film_midpick, best_foreign_language_film_botpick, best_makeup_and_hairstyling_toppick, best_makeup_and_hairstyling_midpick, best_makeup_and_hairstyling_botpick, best_original_score_toppick, best_original_score_midpick, best_original_score_botpick, best_original_song_toppick, best_original_song_midpick, best_original_song_botpick, best_production_design_toppick, best_production_design_midpick, best_production_design_botpick, best_animated_short_film_toppick, best_animated_short_film_midpick, best_animated_short_film_botpick, best_live_action_short_film_toppick, best_live_action_short_film_midpick, best_live_action_short_film_botpick, best_sound_editing_toppick, best_sound_editing_midpick, best_sound_editing_botpick, best_sound_mixing_toppick, best_sound_mixing_midpick, best_sound_mixing_botpick, best_visual_effects_toppick, best_visual_effects_midpick, best_visual_effects_botpick, best_adapted_screenplay_toppick, best_adapted_screenplay_midpick, best_adapted_screenplay_botpick, best_original_screenplay_toppick, best_original_screenplay_midpick, best_original_screenplay_botpick, username, paid) FROM '$$PATH$$/1855.dat';

--
-- Data for Name: winners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY winners (category, winner) FROM stdin;
\.
COPY winners (category, winner) FROM '$$PATH$$/1856.dat';

--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

